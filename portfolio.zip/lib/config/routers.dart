class Routers{

  static const projectHR = "/projects/:HireRickshaw";
  static const projectTP = "/projects/:ToppersClub";
  static const projectIF = "/projects/:Indifun";
  static const projectTTK = "/projects/Taron ki Toli";
  static const projectAIA = "/projects/AIA";
  // static const projectAIA = "/projects/AIA";
}