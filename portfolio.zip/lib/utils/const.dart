import 'package:flutter/material.dart';

class Const{

  static Color colorHeader = Color.fromARGB(255, 44, 44, 44);


  static double windowWidth = 600.0;
}